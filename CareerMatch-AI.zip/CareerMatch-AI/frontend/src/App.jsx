import { Link, Navigate, Route, Routes, useNavigate } from "react-router-dom";
import Auth from "./pages/Auth.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Analyzer from "./pages/Analyzer.jsx";
import History from "./pages/History.jsx";
import Result from "./pages/Result.jsx";
import Onboarding from "./pages/Onboarding.jsx";
import { getUser } from "./user.js";

function Layout({ children, gate = true }) {
  const nav = useNavigate();
  const user = getUser();
  if (!localStorage.getItem("token")) return <Navigate to="/login" />;
  // new users must set qualification + major before anything else
  if (gate && !user.profile_complete) return <Navigate to="/onboarding" />;
  const logout = () => { localStorage.clear(); nav("/login"); };
  return (
    <>
      <header className="nav">
        <Link to="/" className="brand">CareerMatch</Link>
        <nav>
          <Link to="/">Dashboard</Link>
          <Link to="/analyze">Analyze resume</Link>
          <Link to="/history">History</Link>
          <Link to="/profile">Profile</Link>
          <button className="link" onClick={logout}>Log out ({user.name})</button>
        </nav>
      </header>
      <main className="page">{children}</main>
    </>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Auth mode="login" />} />
      <Route path="/register" element={<Auth mode="register" />} />
      <Route path="/" element={<Layout><Dashboard /></Layout>} />
      <Route path="/onboarding" element={<Layout gate={false}><Onboarding /></Layout>} />
      <Route path="/profile" element={<Layout gate={false}><Onboarding /></Layout>} />
      <Route path="/analyze" element={<Layout><Analyzer /></Layout>} />
      <Route path="/history" element={<Layout><History /></Layout>} />
      <Route path="/result/:id" element={<Layout><Result /></Layout>} />
    </Routes>
  );
}
