const token = () => localStorage.getItem("token");

export async function api(path, { method = "GET", body, form } = {}) {
  const headers = {};
  if (token()) headers.Authorization = `Bearer ${token()}`;
  if (body) headers["Content-Type"] = "application/json";
  const res = await fetch(`/api${path}`, { method, headers, body: form || (body && JSON.stringify(body)) });
  const data = await res.json().catch(() => ({}));
  // expired token or deleted user: clear the session and go to login
  if (res.status === 401 && token()) { localStorage.clear(); window.location.href = "/login"; }
  if (!res.ok) throw new Error(data.message || "Something went wrong");
  return data;
}
