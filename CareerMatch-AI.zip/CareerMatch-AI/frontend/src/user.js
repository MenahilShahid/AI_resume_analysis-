// The logged-in user (incl. academic profile) is cached in localStorage.
export const getUser = () => {
  try { return JSON.parse(localStorage.getItem("user") || "{}") || {}; } catch { return {}; }
};
export const setUser = (u) => { if (u) localStorage.setItem("user", JSON.stringify(u)); };
export const profileLine = (p = {}) =>
  [p.degree || p.qualification, p.major || p.major_name].filter(Boolean).join(" · ");
