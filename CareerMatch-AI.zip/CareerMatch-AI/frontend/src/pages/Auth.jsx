import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { setUser } from "../user.js";

export default function Auth({ mode }) {
  const nav = useNavigate();
  const isReg = mode === "register";
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setErr(""); setBusy(true);
    try {
      const d = await api(`/auth/${mode}`, { method: "POST", body: f });
      localStorage.setItem("token", d.token);
      setUser(d.user);
      nav(d.user.profile_complete ? "/" : "/onboarding");
    } catch (x) { setErr(x.message); } finally { setBusy(false); }
  }

  return (
    <div className="auth">
      <div className="auth-side">
        <h1>Your resume, judged by your own field.</h1>
        <p>Tell us your qualification and major, upload a PDF, and get a major-specific score, skill gaps, matching careers, jobs and a learning roadmap. Works for computing, health, business, arts, law, engineering and more.</p>
      </div>
      <form className="auth-form" onSubmit={submit}>
        <h2>{isReg ? "Create your account" : "Log in"}</h2>
        {isReg && <input placeholder="Full name" value={f.name} onChange={set("name")} required />}
        <input type="email" placeholder="Email" value={f.email} onChange={set("email")} required />
        <input type="password" placeholder="Password (6+ characters)" value={f.password} onChange={set("password")} required />
        {err && <p className="error">{err}</p>}
        <button className="btn" disabled={busy}>{busy ? "Please wait..." : isReg ? "Create account" : "Log in"}</button>
        <p className="muted">
          {isReg ? <>Already registered? <Link to="/login">Log in</Link></> : <>New here? <Link to="/register">Create an account</Link></>}
        </p>
      </form>
    </div>
  );
}
