import { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import Results from "./Results.jsx";
import { getUser } from "../user.js";

export default function Analyzer() {
  const [file, setFile] = useState(null);
  const [data, setData] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const user = getUser();

  async function analyze() {
    if (!file) return setErr("Select a PDF resume first.");
    setErr(""); setBusy(true); setData(null);
    const form = new FormData();
    form.append("resume", file);
    try { setData(await api("/resume/analyze", { method: "POST", form })); }
    catch (e) { setErr(e.message); }
    finally { setBusy(false); }
  }

  return (
    <>
      <h1>Analyze your resume</h1>
      <p className="muted">Analyzing as <b>{[user.degree || user.qualification, user.major_name].filter(Boolean).join(" · ")}</b> · <Link to="/profile">change</Link></p>
      <div className="card upload">
        <input type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files[0])} />
        <button className="btn" onClick={analyze} disabled={busy}>{busy ? "Analyzing..." : "Analyze resume"}</button>
      </div>
      {err && <p className="error">{err}</p>}
      {data && <Results data={data} />}
    </>
  );
}
