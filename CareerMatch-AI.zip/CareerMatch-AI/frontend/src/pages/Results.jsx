import { useState } from "react";
import { profileLine } from "../user.js";

const Chips = ({ items, cls }) => (
  <div className="chips">{items.length ? items.map((s) => <span key={s} className={`chip ${cls}`}>{s}</span>) : <span className="muted">None</span>}</div>
);

const Bar = ({ label, value }) => (
  <div className="bar-row">
    <span className="cap">{label}</span>
    <div className="bar"><i style={{ width: `${value}%` }} /></div>
    <b>{value}%</b>
  </div>
);

const LABELS = { skills: "Major skills", experience: "Experience", projects: "Projects", education: "Education" };

function Roadmap({ roadmaps, level }) {
  const [i, setI] = useState(0);
  if (!roadmaps?.length) return null;
  const r = roadmaps[Math.min(i, roadmaps.length - 1)];
  return (
    <div className="card">
      <h3>Personalized learning roadmap</h3>
      <p className="muted">Pick a goal. Current level: <b>{level}</b></p>
      <div className="options" role="tablist">
        {roadmaps.map((x, n) => (
          <button key={x.career_id} type="button" role="tab" aria-selected={n === i} className={`opt ${n === i ? "sel" : ""}`} onClick={() => setI(n)}>{x.career}</button>
        ))}
      </div>
      {r.steps.length === 0 ? <p className="muted">You already cover every core skill for {r.career}. Focus on projects and experience.</p> : (
        <ol className="timeline">
          {r.steps.map((s) => (
            <li key={s.skill}><small>Month {s.month}</small><b>{s.skill}</b><span className={`chip ${s.importance}`}>{s.importance}</span></li>
          ))}
        </ol>
      )}
    </div>
  );
}

export default function Results({ data }) {
  return (
    <div className="stack">
      <div className="card hero">
        <div className="ring" style={{ "--p": data.resume_score }}><span>{data.resume_score}</span></div>
        <div>
          <h2>Resume score</h2>
          <p className="muted">{data.file_name}</p>
          <p className="muted">{profileLine(data.profile)}{data.level && <> · <b>{data.level}</b> level</>}</p>
        </div>
      </div>

      <div className="card">
        <h3>Score breakdown</h3>
        <p className="muted">The skills score is measured against the skill framework for {data.profile?.major || "your major"}.</p>
        {Object.entries(data.breakdown).map(([k, v]) => <Bar key={k} label={LABELS[k] || k} value={v} />)}
      </div>

      <div className="grid two">
        <div className="card">
          <h3>Strong areas</h3>
          <Chips items={data.strong} cls="ok" />
        </div>
        <div className="card">
          <h3>Skills to improve</h3>
          {data.skill_gap.length === 0 ? <p className="muted">No major gaps found.</p> :
            <div className="chips">{data.skill_gap.map((g) => <span key={g.skill} className={`chip ${g.priority}`}>{g.skill} · {g.priority}</span>)}</div>}
        </div>
      </div>

      {data.careers.length > 0 && (
        <div className="card">
          <h3>Suitable careers</h3>
          {data.careers.slice(0, 5).map((c, n) => (
            <div className="job" key={c.career_id}>
              <div className="job-head">
                <div><b>{n + 1}. {c.career_name}</b><div className="muted">{c.description}</div></div>
                <b className="pct">{c.match_score}%</b>
              </div>
              <div className="bar"><i style={{ width: `${c.match_score}%` }} /></div>
              <div className="split">
                <div><small>You have</small><Chips items={c.matched_skills} cls="ok" /></div>
                <div><small>To learn</small><Chips items={c.missing_skills} cls="miss" /></div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Roadmap roadmaps={data.roadmaps} level={data.level} />

      <div className="card">
        <h3>Recommended jobs</h3>
        {data.matches.length === 0 && <p className="muted">No jobs listed for this field yet.</p>}
        {data.matches.slice(0, 8).map((m) => (
          <div className="job" key={m.job_id}>
            <div className="job-head">
              <div><b>{m.title}</b><div className="muted">{m.company} · {m.location} · {m.job_type}</div></div>
              <b className="pct">{m.match_score}%</b>
            </div>
            <div className="bar"><i style={{ width: `${m.match_score}%` }} /></div>
            <div className="split">
              <div><small>Matched</small><Chips items={m.matched_skills} cls="ok" /></div>
              <div><small>Missing</small><Chips items={m.missing_skills} cls="miss" /></div>
            </div>
          </div>
        ))}
      </div>

      {data.advice.length > 0 && (
        <div className="card">
          <h3>Personalized advice</h3>
          <ul className="advice">{data.advice.map((t) => <li key={t}>{t}</li>)}</ul>
        </div>
      )}

      <div className="card">
        <h3>All detected skills ({data.skills.length})</h3>
        <Chips items={data.skills} cls="ok" />
      </div>
    </div>
  );
}
