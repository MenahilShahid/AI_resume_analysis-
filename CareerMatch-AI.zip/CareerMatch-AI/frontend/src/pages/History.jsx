import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";

export default function History() {
  const [rows, setRows] = useState(null);
  useEffect(() => { api("/resume/history").then(setRows); }, []);
  if (!rows) return <p className="muted">Loading...</p>;
  return (
    <>
      <h1>Analysis history</h1>
      {rows.length === 0 ? <div className="card empty"><p className="muted">No analyses yet.</p><Link className="btn" to="/analyze">Analyze a resume</Link></div> : (
        <div className="card">
          <table>
            <thead><tr><th>Date</th><th>Resume</th><th>Major</th><th>Score</th><th></th></tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r.id}>
                <td>{new Date(r.created_at).toLocaleDateString()}</td>
                <td>{r.file_name}</td><td>{r.major_name || "-"}</td><td><b>{r.resume_score}%</b></td>
                <td><Link to={`/result/${r.id}`}>Open</Link></td>
              </tr>))}</tbody>
          </table>
        </div>
      )}
    </>
  );
}
