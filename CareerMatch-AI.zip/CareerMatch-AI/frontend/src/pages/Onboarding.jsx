import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { getUser, setUser } from "../user.js";

const STEPS = ["Qualification", "Major", "Confirm"];

export default function Onboarding() {
  const nav = useNavigate();
  const existing = getUser();
  const [opts, setOpts] = useState(null);
  const [step, setStep] = useState(0);
  const [qualification, setQualification] = useState(existing.qualification || "");
  const [degree, setDegree] = useState(existing.degree || "");
  const [majorId, setMajorId] = useState(existing.major_id || null);
  const [query, setQuery] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { api("/profile/options").then(setOpts).catch((e) => setErr(e.message)); }, []);
  if (!opts) return err ? <p className="error">{err}</p> : <p className="muted">Loading...</p>;

  const degrees = opts.degrees[qualification];
  const major = opts.categories.flatMap((c) => c.majors.map((m) => ({ ...m, category: c.category }))).find((m) => m.id === majorId);
  const canNext = step === 0 ? qualification && (!degrees || degree) : step === 1 ? Boolean(majorId) : true;
  const q = query.trim().toLowerCase();

  async function save() {
    setErr(""); setBusy(true);
    try {
      const u = await api("/profile", { method: "PUT", body: { qualification, degree: degrees ? degree : null, major_id: majorId } });
      setUser(u);
      nav("/analyze");
    } catch (e) { setErr(e.message); } finally { setBusy(false); }
  }

  return (
    <div className="wizard">
      <h1>Let's build your career profile</h1>
      <p className="muted">Your resume is judged against your own field, not a one-size-fits-all checklist.</p>
      <ol className="steps">
        {STEPS.map((s, i) => <li key={s} className={i === step ? "on" : i < step ? "done" : ""}><span>{i + 1}</span>{s}</li>)}
      </ol>

      <div className="card">
        {step === 0 && (
          <>
            <h3>Select your qualification</h3>
            <div className="options">
              {opts.qualifications.map((o) => (
                <button key={o} type="button" aria-pressed={qualification === o} className={`opt ${qualification === o ? "sel" : ""}`}
                  onClick={() => { setQualification(o); setDegree(""); }}>{o}</button>
              ))}
            </div>
            {degrees && (
              <>
                <h3 className="gap">Which degree?</h3>
                <div className="options">
                  {degrees.map((d) => (
                    <button key={d} type="button" aria-pressed={degree === d} className={`opt ${degree === d ? "sel" : ""}`} onClick={() => setDegree(d)}>{d}</button>
                  ))}
                </div>
              </>
            )}
          </>
        )}

        {step === 1 && (
          <>
            <h3>What's your major?</h3>
            <input placeholder="Search majors (e.g. English, Nursing, Fashion)" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search majors" />
            {opts.categories.map((c) => {
              const list = c.majors.filter((m) => !q || m.name.toLowerCase().includes(q) || c.category.toLowerCase().includes(q));
              return list.length ? (
                <div key={c.category} className="cat">
                  <small>{c.category}</small>
                  <div className="options">
                    {list.map((m) => (
                      <button key={m.id} type="button" aria-pressed={majorId === m.id} className={`opt ${majorId === m.id ? "sel" : ""}`} onClick={() => setMajorId(m.id)}>{m.name}</button>
                    ))}
                  </div>
                </div>
              ) : null;
            })}
          </>
        )}

        {step === 2 && (
          <>
            <h3>Looks right?</h3>
            <dl className="summary">
              <dt>Qualification</dt><dd>{qualification}{degrees ? ` (${degree})` : ""}</dd>
              <dt>Major</dt><dd>{major?.name}</dd>
              <dt>Field</dt><dd>{major?.category}</dd>
            </dl>
            <p className="muted">Next you'll upload your CV and get a score, skill gaps, career matches and a learning roadmap for this major. You can change this any time from Profile.</p>
          </>
        )}
      </div>

      {err && <p className="error">{err}</p>}
      <div className="wiz-actions">
        {step > 0 && <button type="button" className="btn ghost" onClick={() => setStep(step - 1)}>Back</button>}
        {step < 2
          ? <button type="button" className="btn" disabled={!canNext} onClick={() => setStep(step + 1)}>Next</button>
          : <button type="button" className="btn" disabled={busy} onClick={save}>{busy ? "Saving..." : "Save & continue"}</button>}
      </div>
    </div>
  );
}
