import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { setUser, profileLine } from "../user.js";

export default function Dashboard() {
  const [d, setD] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    api("/resume/dashboard").then((x) => { setD(x); setUser(x.profile); }).catch((e) => setErr(e.message));
  }, []);

  if (err) return <p className="error">{err}</p>;
  if (!d) return <p className="muted">Loading...</p>;

  const p = d.profile;
  const steps = d.roadmap?.steps || [];
  return (
    <>
      <h1>Hello, {p.name}</h1>
      <p className="muted">{profileLine({ degree: p.degree || p.qualification, major: p.major_name })} · <Link to="/profile">edit profile</Link></p>
      {!d.hasResume ? (
        <div className="card empty">
          <h3>No resume analyzed yet</h3>
          <p className="muted">Upload a PDF resume to see your major-specific score, careers, skill gaps and roadmap.</p>
          <Link className="btn" to="/analyze">Analyze my resume</Link>
        </div>
      ) : (
        <>
          {d.resume_profile?.major && d.resume_profile.major !== p.major_name &&
            <p className="notice">Your latest analysis was for {d.resume_profile.major}. Analyze again to get results for {p.major_name}.</p>}
          <div className="grid">
            <div className="card stat"><b>{d.resume_score}</b><span>Resume score{d.level ? ` · ${d.level}` : ""}</span></div>
            <div className="card stat"><b>{d.best_career ? `${d.best_career.match_score}%` : "-"}</b><span>Best career match</span></div>
            <div className="card stat"><b>{d.skills_count}</b><span>Skills detected</span></div>
            <div className="card stat"><b>{d.jobs_matched}</b><span>Jobs matched (50%+)</span></div>
          </div>

          {d.best_career && (
            <div className="card">
              <small>Best career match</small>
              <h3>{d.best_career.career_name} · {d.best_career.match_score}%</h3>
              <p className="muted">{d.best_career.description}</p>
              {d.best_job && <p className="muted">Top job: <b>{d.best_job.title}</b> at {d.best_job.company} ({d.best_job.match_score}%)</p>}
            </div>
          )}

          <div className="grid two">
            <div className="card">
              <h3>Skills to improve</h3>
              {d.skill_gap.length === 0 ? <p className="muted">No major gaps found.</p> :
                <div className="chips">{d.skill_gap.map((g) => <span key={g.skill} className={`chip ${g.priority}`}>{g.skill} · {g.priority}</span>)}</div>}
            </div>
            <div className="card">
              <h3>Recommended roadmap</h3>
              {steps.length === 0 ? <p className="muted">You already cover the core skills for your top career.</p> :
                <p className="path">{steps.slice(0, 4).map((s) => s.skill).join(" → ")}</p>}
              {d.roadmap && <small>Goal: {d.roadmap.career}</small>}
            </div>
          </div>

          <div className="actions">
            <Link className="btn" to="/analyze">Analyze new resume</Link>
            <Link className="btn ghost" to={`/result/${d.resume_id}`}>View full results</Link>
          </div>
        </>
      )}
    </>
  );
}
