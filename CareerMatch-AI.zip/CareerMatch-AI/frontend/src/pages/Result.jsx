import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../api.js";
import Results from "./Results.jsx";

export default function Result() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => { api(`/resume/${id}`).then(setData).catch((e) => setErr(e.message)); }, [id]);
  if (err) return <p className="error">{err}</p>;
  return data ? <Results data={data} /> : <p className="muted">Loading...</p>;
}
