# CareerMatch AI - Multi-Disciplinary Resume & Career Advisor
Judges a resume against the user's own major (not just Computer Science), finds skill gaps, matches careers and jobs, and builds a learning roadmap.
Stack: React, Node/Express, MySQL, Python (Flask, pdfplumber, scikit-learn TF-IDF).

## Flow
Register/Login -> Academic profile (qualification, degree, major) -> Upload PDF CV -> major-specific score, strong areas, skill gaps, career matches, learning roadmap, jobs.

## Run (4 terminals)
1. XAMPP: start MySQL, import `database/careermatch.sql` in phpMyAdmin. **It resets the tables**, so register again after importing.
2. `cd ml-service && pip install -r requirements.txt && python app.py`   (port 8000)
3. `cd backend && npm install && npm start`                              (port 5000)
4. `cd frontend && npm install && npm run dev`                           (http://localhost:5173)

## Architecture
```
Profile (qualification + major) -> CV upload -> Express loads the major's knowledge base from MySQL
 -> Python NLP: skill extraction -> Major framework -> Resume score / Skill gap / Career match / Roadmap
```
Tables: `majors`, `skills`, `major_skills`, `careers`, `career_skills`, `users`, `resumes`, `career_matches`, `jobs`, `matches`.

## How scoring works
- **Skills (50%)**: importance-weighted coverage (High=3, Medium=2, Low=1) of the major's skill framework; 70% coverage = full marks. Then experience 20%, projects 15%, education 15%.
- **Career match** = 85% weighted skill coverage + 15% TF-IDF similarity (resume vs career text).
- **Job match** = 70% skill overlap + 30% TF-IDF similarity.
- **Level**: Beginner < 35% coverage, Intermediate < 65%, Advanced above.
- **Roadmap**: missing skills of a chosen career, High priority first, one skill per month.

## Majors and frameworks
50 majors in 9 categories + "Other". 27 have a curated framework (skills, careers, jobs); related majors reuse the closest one through `majors.framework_id` (e.g. Textile Design -> Fashion Design framework).

## Add a new major / skill / career (no code change)
```sql
INSERT INTO majors (name, category, framework_id) VALUES ('Sports Science', 'Science', NULL);
UPDATE majors SET framework_id = id WHERE name = 'Sports Science';        -- own framework
INSERT INTO skills (name, category, aliases) VALUES ('Sports Nutrition', 'Science', 'sports nutrition,nutrition planning');
INSERT INTO major_skills (major_id, skill_id, importance)
  SELECT m.id, s.id, 'High' FROM majors m, skills s WHERE m.name='Sports Science' AND s.name='Sports Nutrition';
INSERT INTO careers (career_name, major_id, description)
  SELECT 'Sports Nutritionist', id, 'Plan nutrition for athletes' FROM majors WHERE name='Sports Science';
```
To reuse an existing framework instead, set `framework_id` to the id of that major.
