"""CareerMatch AI - NLP service.

Stateless: the Express backend sends the knowledge base for the user's major
(skill catalog, major skill framework, careers, jobs) with every request, so new
majors/skills/careers can be added in MySQL without touching this code.
"""
import io
import json
import re

import pdfplumber
from flask import Flask, jsonify, request
from flask_cors import CORS
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)
CORS(app)

WEIGHT = {"High": 3, "Medium": 2, "Low": 1}
ORDER = {"High": 0, "Medium": 1, "Low": 2}
FULL_COVERAGE = 0.70  # covering 70% of a major's weighted framework counts as a full skills score


# ------------------------------------------------------------------ text helpers
def pdf_to_text(file_storage) -> str:
    with pdfplumber.open(io.BytesIO(file_storage.read())) as pdf:
        return "\n".join((page.extract_text() or "") for page in pdf.pages)


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9+#.\s]", " ", text.lower())).strip()


def extract_skills(text: str, catalog: list) -> list:
    """Return catalog skill names found in text (alias match on word boundaries)."""
    t = text.lower()
    found = []
    for item in catalog:
        for alias in item.get("aliases", []):
            alias = alias.strip().lower()
            if alias and re.search(r"(?<![a-z0-9+#.])" + re.escape(alias) + r"(?![a-z0-9+#])", t):
                found.append(item["name"])
                break
    return found


def weighted_coverage(have: set, required: list):
    """required: [{name, importance}] -> (coverage 0..1, matched[], missing[]) ordered by importance."""
    ordered = sorted(required, key=lambda r: ORDER.get(r["importance"], 1))
    total = sum(WEIGHT.get(r["importance"], 2) for r in ordered)
    matched = [r["name"] for r in ordered if r["name"] in have]
    missing = [r for r in ordered if r["name"] not in have]
    got = sum(WEIGHT.get(r["importance"], 2) for r in ordered if r["name"] in have)
    return (got / total if total else 0.0), matched, missing


# ------------------------------------------------------------------ scoring
def score_resume(text: str, coverage: float) -> dict:
    t = text.lower()
    has = lambda pattern: bool(re.search(pattern, t))
    b = {
        "skills": min(round(coverage * 100 / FULL_COVERAGE), 100),
        "experience": 100 if has(r"\b(experience|internship|intern|employment|work history|volunteer|practicum|clinical rotations?|teaching practice|apprenticeship)\b") else 35,
        "projects": 100 if has(r"\b(projects?|portfolio|publications?|research|thesis|dissertation|case stud(y|ies))\b") else 35,
        "education": 100 if has(r"\b(education|university|bachelor|degree|college|intermediate|bs|bsc|mba|llb|master)\b") else 35,
    }
    b["overall"] = round(b["skills"] * 0.5 + b["experience"] * 0.2 + b["projects"] * 0.15 + b["education"] * 0.15)
    return b


def level_of(coverage: float) -> str:
    return "Advanced" if coverage >= 0.65 else "Intermediate" if coverage >= 0.35 else "Beginner"


def similarities(resume_text: str, docs: list) -> list:
    if not docs:
        return []
    try:
        tfidf = TfidfVectorizer(stop_words="english", ngram_range=(1, 2)).fit_transform([clean(resume_text)] + [clean(d) for d in docs])
        return [float(s) for s in cosine_similarity(tfidf[0:1], tfidf[1:])[0]]
    except ValueError:  # empty vocabulary
        return [0.0] * len(docs)


def match_careers(text: str, have: set, careers: list) -> list:
    sims = similarities(text, [f"{c['name']} {c.get('description', '')} {' '.join(s['name'] for s in c['skills'])}" for c in careers])
    out = []
    for c, sim in zip(careers, sims):
        cov, matched, missing = weighted_coverage(have, c["skills"])
        # 85% weighted skill coverage + 15% TF-IDF text similarity
        score = round(100 * (0.85 * cov + 0.15 * sim))
        out.append({
            "career_id": c["id"], "name": c["name"], "description": c.get("description", ""),
            "match_score": score, "matched_skills": matched,
            "missing_skills": [m["name"] for m in missing], "missing_detail": missing,
        })
    out.sort(key=lambda m: m["match_score"], reverse=True)
    return out


def build_roadmaps(top_careers: list, limit: int = 3, steps: int = 6) -> list:
    roadmaps = []
    for c in top_careers[:limit]:
        items = c["missing_detail"][:steps]
        roadmaps.append({
            "career_id": c["career_id"], "career": c["name"],
            "steps": [{"month": i + 1, "skill": m["name"], "importance": m["importance"]} for i, m in enumerate(items)],
        })
    return roadmaps


def build_advice(text: str, b: dict, level: str, improve: list, best) -> list:
    tips = []
    if best:
        tips.append(f"Your strongest career direction is {best['name']} ({best['match_score']}% match).")
    if improve:
        tips.append("Close the biggest gaps first: " + ", ".join(i["skill"] for i in improve[:3]) + ".")
    if b["experience"] < 100:
        tips.append("Add an Experience section (internships, volunteering, part-time or practical work).")
    if b["projects"] < 100:
        tips.append("Add a Projects / Portfolio / Research section that shows your work.")
    if b["education"] < 100:
        tips.append("List your education clearly: degree, institution and years.")
    if len(text.split()) < 150:
        tips.append("Your resume is short - add measurable achievements and more detail.")
    if level == "Beginner":
        tips.append("Build the High-priority skills for your major before applying widely.")
    return tips


# ------------------------------------------------------------------ routes
@app.get("/health")
def health():
    return jsonify(status="ok")


@app.post("/analyze")
def analyze():
    f = request.files.get("resume")
    if not f:
        return jsonify(error="Resume file missing"), 400
    try:
        ctx = json.loads(request.form.get("context", ""))
        catalog, framework = ctx["catalog"], ctx["framework_skills"]
        careers, jobs = ctx.get("careers", []), ctx.get("jobs", [])
    except (ValueError, KeyError, TypeError):
        return jsonify(error="Missing or invalid analysis context"), 400
    try:
        text = pdf_to_text(f)
    except Exception:
        return jsonify(error="PDF read nahi ho saki"), 400
    if len(text.strip()) < 50:
        return jsonify(error="PDF mein text nahi mila (scanned PDF ho sakti hai)"), 400

    skills = extract_skills(text, catalog)
    have = set(skills)

    # major-specific analysis
    coverage, strong, missing = weighted_coverage(have, framework)
    b = score_resume(text, coverage)
    improve = [{"skill": m["name"], "priority": m["importance"]} for m in missing[:8]]
    fw_names = {s["name"] for s in framework}
    level = level_of(coverage)

    career_matches = match_careers(text, have, careers)
    roadmaps = build_roadmaps(career_matches)
    advice = build_advice(text, b, level, improve, career_matches[0] if career_matches else None)

    # job matching (70% skill overlap + 30% TF-IDF similarity)
    job_matches = []
    sims = similarities(text, [f"{j['title']} {j.get('description', '')} {j.get('required_skills', '')}" for j in jobs])
    lower_have = {s.lower() for s in skills}
    for job, sim in zip(jobs, sims):
        required = [s.strip() for s in job["required_skills"].split(",") if s.strip()]
        matched = [s for s in required if s.lower() in lower_have]
        absent = [s for s in required if s.lower() not in lower_have]
        overlap = len(matched) / len(required) if required else 0
        job_matches.append({
            "job_id": job["id"], "match_score": round(100 * (0.7 * overlap + 0.3 * sim)),
            "matched_skills": matched, "missing_skills": absent,
        })
    job_matches.sort(key=lambda m: m["match_score"], reverse=True)

    for c in career_matches:
        c.pop("missing_detail")  # only needed to build the roadmaps
    return jsonify(
        text=text, skills=skills, resume_score=b.pop("overall"), breakdown=b,
        analysis={
            "level": level, "coverage": round(coverage * 100), "strong": strong, "improve": improve,
            "other_skills": [s for s in skills if s not in fw_names], "roadmaps": roadmaps, "advice": advice,
        },
        career_matches=career_matches, job_matches=job_matches,
    )


if __name__ == "__main__":
    app.run(port=8000, debug=True)
