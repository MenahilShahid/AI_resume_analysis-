const router = require("express").Router();
const multer = require("multer");
const pool = require("../config/db");
const auth = require("../middleware/auth");
const { userPayload, wrap } = require("../utils/user");

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
const ML = process.env.ML_URL || "http://127.0.0.1:8000";
const json = (v, fallback) => { try { return v ? JSON.parse(v) : fallback; } catch { return fallback; } };

// Everything the NLP service needs for one major. Majors without their own
// framework reuse the closest one (majors.framework_id); unknown ones fall back to "Other".
async function loadContext(majorId) {
  const [[major]] = await pool.query("SELECT id, name, category, framework_id FROM majors WHERE id = ?", [majorId]);
  let fid = major.framework_id || major.id;
  let [framework] = await pool.query(
    "SELECT s.name, ms.importance FROM major_skills ms JOIN skills s ON s.id = ms.skill_id WHERE ms.major_id = ?", [fid]);
  if (!framework.length) {
    const [[other]] = await pool.query("SELECT id, framework_id FROM majors WHERE name = 'Other'");
    fid = other.framework_id || other.id;
    [framework] = await pool.query(
      "SELECT s.name, ms.importance FROM major_skills ms JOIN skills s ON s.id = ms.skill_id WHERE ms.major_id = ?", [fid]);
  }
  const [skills] = await pool.query("SELECT name, aliases FROM skills");
  const [careers] = await pool.query("SELECT id, career_name AS name, description FROM careers WHERE major_id = ?", [fid]);
  const [careerSkills] = await pool.query(
    `SELECT cs.career_id, s.name, cs.importance FROM career_skills cs
     JOIN skills s ON s.id = cs.skill_id JOIN careers c ON c.id = cs.career_id WHERE c.major_id = ?`, [fid]);
  const [jobs] = await pool.query("SELECT id, title, description, required_skills FROM jobs WHERE major_id = ?", [fid]);
  return {
    major,
    context: {
      catalog: skills.map((s) => ({ name: s.name, aliases: (s.aliases || s.name.toLowerCase()).split(",") })),
      framework_skills: framework,
      careers: careers.map((c) => ({ ...c, skills: careerSkills.filter((x) => x.career_id === c.id).map(({ name, importance }) => ({ name, importance })) })),
      jobs,
    },
  };
}

async function loadResult(id, userId) {
  const [rows] = await pool.query(
    `SELECT r.*, m.name AS major_name FROM resumes r LEFT JOIN majors m ON m.id = r.major_id
     WHERE r.id = ? AND r.user_id = ?`, [id, userId]);
  if (!rows.length) return null;
  const r = rows[0];
  const [m] = await pool.query(
    `SELECT m.job_id, m.match_score, m.matched_skills, m.missing_skills, j.title, j.company, j.location, j.job_type
     FROM matches m JOIN jobs j ON j.id = m.job_id WHERE m.resume_id = ? ORDER BY m.match_score DESC`, [id]);
  const [c] = await pool.query(
    `SELECT cm.career_id, cm.match_score, cm.matched_skills, cm.missing_skills, c.career_name, c.description
     FROM career_matches cm JOIN careers c ON c.id = cm.career_id WHERE cm.resume_id = ? ORDER BY cm.match_score DESC`, [id]);
  const parse = (x) => ({ ...x, matched_skills: json(x.matched_skills, []), missing_skills: json(x.missing_skills, []) });
  const a = json(r.analysis, {});
  return {
    id: r.id, file_name: r.file_name, created_at: r.created_at, resume_score: r.resume_score,
    skills: json(r.skills, []), breakdown: json(r.breakdown, {}),
    profile: a.profile || { major: r.major_name },
    level: a.level || null, coverage: a.coverage ?? null,
    strong: a.strong || [], other_skills: a.other_skills || [], advice: a.advice || [],
    skill_gap: a.improve || [], roadmaps: a.roadmaps || [],
    careers: c.map(parse), matches: m.map(parse),
  };
}

router.post("/analyze", auth, upload.single("resume"), wrap(async (req, res) => {
  if (!req.file) return res.status(400).json({ message: "Pehle PDF resume select karein" });
  const user = await userPayload(req.user.id);
  if (!user || !user.profile_complete)
    return res.status(400).json({ message: "Please complete your academic profile first" });

  const { major, context } = await loadContext(user.major_id);
  const fd = new FormData();
  fd.append("resume", new Blob([req.file.buffer], { type: "application/pdf" }), req.file.originalname);
  fd.append("context", JSON.stringify(context));
  let a;
  try { a = await fetch(`${ML}/analyze`, { method: "POST", body: fd }); }
  catch { return res.status(502).json({ message: "Python ML service (port 8000) chal rahi hai?" }); }
  const out = await a.json();
  if (!a.ok) return res.status(400).json({ message: out.error || "Resume analyze nahi hua" });

  const analysis = {
    ...out.analysis,
    profile: { qualification: user.qualification, degree: user.degree, major: major.name, category: major.category },
  };
  const [ins] = await pool.query(
    "INSERT INTO resumes (user_id,major_id,file_name,extracted_text,skills,resume_score,breakdown,analysis) VALUES (?,?,?,?,?,?,?,?)",
    [req.user.id, user.major_id, req.file.originalname, out.text, JSON.stringify(out.skills), out.resume_score,
      JSON.stringify(out.breakdown), JSON.stringify(analysis)]
  );
  if (out.career_matches.length)
    await pool.query(
      "INSERT INTO career_matches (resume_id,career_id,match_score,matched_skills,missing_skills) VALUES ?",
      [out.career_matches.map((m) => [ins.insertId, m.career_id, m.match_score, JSON.stringify(m.matched_skills), JSON.stringify(m.missing_skills)])]
    );
  if (out.job_matches.length)
    await pool.query(
      "INSERT INTO matches (user_id,resume_id,job_id,match_score,matched_skills,missing_skills) VALUES ?",
      [out.job_matches.map((m) => [req.user.id, ins.insertId, m.job_id, m.match_score, JSON.stringify(m.matched_skills), JSON.stringify(m.missing_skills)])]
    );
  res.json(await loadResult(ins.insertId, req.user.id));
}));

router.get("/history", auth, wrap(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT r.id, r.file_name, r.resume_score, r.created_at, m.name AS major_name
     FROM resumes r LEFT JOIN majors m ON m.id = r.major_id WHERE r.user_id = ? ORDER BY r.created_at DESC, r.id DESC`, [req.user.id]);
  res.json(rows);
}));

router.get("/dashboard", auth, wrap(async (req, res) => {
  const profile = await userPayload(req.user.id);
  if (!profile) return res.status(401).json({ message: "Login required" });
  const [rows] = await pool.query("SELECT id FROM resumes WHERE user_id = ? ORDER BY id DESC LIMIT 1", [req.user.id]);
  if (!rows.length) return res.json({ profile, hasResume: false });
  const r = await loadResult(rows[0].id, req.user.id);
  res.json({
    profile, hasResume: true, resume_id: r.id, resume_profile: r.profile, resume_score: r.resume_score,
    level: r.level, skills_count: r.skills.length,
    jobs_matched: r.matches.filter((m) => m.match_score >= 50).length,
    best_career: r.careers[0] || null, best_job: r.matches[0] || null,
    skill_gap: r.skill_gap.slice(0, 6), roadmap: r.roadmaps.find((x) => x.steps.length) || r.roadmaps[0] || null,
  });
}));

router.get("/:id", auth, wrap(async (req, res) => {
  const r = await loadResult(req.params.id, req.user.id);
  r ? res.json(r) : res.status(404).json({ message: "Result nahi mila" });
}));

module.exports = router;
