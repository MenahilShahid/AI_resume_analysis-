const router = require("express").Router();
const pool = require("../config/db");
const auth = require("../middleware/auth");
const { userPayload, wrap } = require("../utils/user");

const QUALIFICATIONS = ["Intermediate", "Associate Degree", "Bachelor's", "Master's", "MPhil", "PhD"];
// Qualifications that need a degree type (BS / BBA / MS ...). The others have none.
const DEGREES = {
  "Bachelor's": ["BS", "BSc", "BBA", "BA", "BEd", "BE / BEng", "LLB", "MBBS", "PharmD", "Other"],
  "Master's": ["MS", "MSc", "MBA", "MA", "MEd", "LLM", "Other"],
};

// Dropdown data for the onboarding wizard: qualifications, degrees and majors grouped by category.
router.get("/options", auth, wrap(async (req, res) => {
  const [majors] = await pool.query("SELECT id, name, category FROM majors ORDER BY id");
  const categories = [];
  for (const m of majors) {
    let c = categories.find((x) => x.category === m.category);
    if (!c) categories.push((c = { category: m.category, majors: [] }));
    c.majors.push({ id: m.id, name: m.name });
  }
  res.json({ qualifications: QUALIFICATIONS, degrees: DEGREES, categories });
}));

router.get("/", auth, wrap(async (req, res) => {
  const user = await userPayload(req.user.id);
  user ? res.json(user) : res.status(401).json({ message: "Login required" });
}));

router.put("/", auth, wrap(async (req, res) => {
  const { qualification, degree, major_id } = req.body;
  if (!QUALIFICATIONS.includes(qualification))
    return res.status(400).json({ message: "Please select your qualification" });
  const needsDegree = Boolean(DEGREES[qualification]);
  if (needsDegree && !DEGREES[qualification].includes(degree))
    return res.status(400).json({ message: "Please select your degree" });
  const [m] = await pool.query("SELECT id FROM majors WHERE id = ?", [major_id]);
  if (!m.length) return res.status(400).json({ message: "Please select your major" });

  await pool.query("UPDATE users SET qualification = ?, degree = ?, major_id = ? WHERE id = ?",
    [qualification, needsDegree ? degree : null, major_id, req.user.id]);
  res.json(await userPayload(req.user.id));
}));

module.exports = router;
