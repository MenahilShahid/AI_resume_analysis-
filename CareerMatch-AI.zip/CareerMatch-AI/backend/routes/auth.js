const router = require("express").Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const pool = require("../config/db");
const { userPayload } = require("../utils/user");

const sign = (u) => jwt.sign({ id: u.id, name: u.name }, process.env.JWT_SECRET, { expiresIn: "7d" });

router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 6)
      return res.status(400).json({ message: "Name, email aur 6+ character password zaroori hai" });
    const [exists] = await pool.query("SELECT id FROM users WHERE email = ?", [email]);
    if (exists.length) return res.status(409).json({ message: "Email pehle se registered hai" });
    const hash = await bcrypt.hash(password, 10);
    const [r] = await pool.query("INSERT INTO users (name,email,password) VALUES (?,?,?)", [name, email, hash]);
    const user = await userPayload(r.insertId);
    res.json({ token: sign(user), user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
    if (!rows.length || !(await bcrypt.compare(password, rows[0].password)))
      return res.status(401).json({ message: "Email ya password ghalat hai" });
    const user = await userPayload(rows[0].id);
    res.json({ token: sign(user), user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
