const pool = require("../config/db");

// Public shape of a user (never includes the password hash).
async function userPayload(id) {
  const [rows] = await pool.query(
    `SELECT u.id, u.name, u.email, u.qualification, u.degree, u.major_id,
            m.name AS major_name, m.category AS major_category
     FROM users u LEFT JOIN majors m ON m.id = u.major_id WHERE u.id = ?`, [id]);
  if (!rows.length) return null;
  const u = rows[0];
  return { ...u, profile_complete: Boolean(u.qualification && u.major_id) };
}

// Express 4 does not catch async errors; this keeps a failed query from hanging the request.
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch((e) => {
  console.error(e);
  res.status(500).json({ message: "Server error" });
});

module.exports = { userPayload, wrap };
